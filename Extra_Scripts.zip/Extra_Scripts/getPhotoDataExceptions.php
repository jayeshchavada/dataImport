<?php
/////////////////////////////////////////////////
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
ini_set("memory_limit","512M");
set_time_limit(0);
ini_set('max_input_time', 3600);
//////////////////////////////////////////////////

class getExceptions
{
    public function __construct()
    {
        include '../database.php';
        $this->con = $con;
        $this->con_working = $con_working;
    }

    public function getOpdFromDb()
    {
        $getQuery = "SELECT * FROM patientregistration";

        $data  = $this->con->query($getQuery);

        while($row = mysqli_fetch_assoc($data))
        {
            $opdNo[] = $row['OpdRegNo'];
        }
    }

    public function getNamesFromDb()
    {
        $getQuery = "SELECT * FROM patientregistration";

        $data  = $this->con->query($getQuery);

        while($row = mysqli_fetch_assoc($data))
        {
            $fullName[] = $row['FirstName']." ".$row['MiddleName']." ".$row['LastName'];
            $Opds[]     =   $row['OpdRegNo'];
        }

        $OpdWithNames = array_combine($Opds,$fullName);
        $getDoubleNames = array_count_values($OpdWithNames);
        
        foreach($getDoubleNames as $key=>$values)
        {
            if($values > 1)
            {
                
                foreach($OpdWithNames as $opdnumber => $name)
                {
                    if($name == $key)
                    {
                        $recordsName[]  =   $name;
                        $recordsOpd[]   =   $opdnumber;
                    }
                }
            }
        }

        $DuplicateRecods = array_combine($recordsOpd,$recordsName);
        
        $emptyTable = $this->con_working->query("TRUNCATE table Temp_Duplicate_Names_Data");

        foreach($DuplicateRecods as $opd => $fullname)
        {
            $Patient = $this->getPatientDataUsingOpd($opd);
            
            $opdofPatient   =   $Patient['OpdRegNo'];
            $patientName    =   $fullname;
            $patientAddress =   $Patient['Address'];
            $patientDOB     =   $Patient['DateOfBirth'];

            $insertQuery    =   "INSERT INTO Temp_Duplicate_Names_Data(OPD,Name,Address,DateofBirth)VALUES('$opdofPatient','$patientName','$patientAddress','$patientDOB')";
            if(!$this->con_working->query($insertQuery)){
                echo mysqli_error($this->con_working);
            }
            else{
                echo "Inserted";
            }
        }
    }

    public function getDuplicateOpdFromDisk()
    {
        $Source = "/media/jc-admin/Seagate Backup Plus Drive/Rupali";

        $foldersInSource = glob("$Source/*",GLOB_BRACE);
        echo "<pre>";
        print_r(scandir($Source));
        echo "</pre>";
        foreach($foldersInSource as $folders)
        {
            $folderNameArray = explode(" ",$folders);

            $OpdFromFolders[] = end($folderNameArray);
        }
        
    }

    public function getDuplicateNamesFromDisk()
    {
        $Source = "";

        $foldersInSource = glob("$Source/*",GLOB_BRACE);

        foreach($foldersInSource as $folders)
        {
            $folderNameArray = explode(" ",$folders);

            $opd = end($folderNameArray);
            
            unset($opd);

            $nameFromFolders[] = implode(" ",$folderNameArray);
        }
        echo "<pre>";
        print_r($nameFromFolders);
        echo "</pre>";
    }

    public function getPatientDataUsingOpd($opd)
    {
        $getQuery = "SELECT * FROM patientregistration WHERE OpdRegNo = '$opd'";

        $data  = $this->con->query($getQuery);

        if($data->num_rows > 0)
        {
            while($row = mysqli_fetch_assoc($data))
            {
                return $row;
                exit;
            }
        }
        
    }
}
$run = new getExceptions();
// $run->getOpdFromDb();
// $run->getNamesFromDb();
$run->getDuplicateOpdFromDisk();
// $run->getDuplicateNamesFromDisk();

?>