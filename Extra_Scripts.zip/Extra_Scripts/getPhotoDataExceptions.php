<?php
//////////////////////////////////

error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
ini_set("memory_limit","512M");
set_time_limit(0);
ini_set('max_input_time', 3600);

//////////////////////////////////

class getExceptions
{
    public function __construct()
    {
        include '../database.php';
        $this->con = $con;
    }

    public function getOpdFromDb()
    {
        $getQuery = "SELECT * FROM patientregistration";

        $data  = $this->con->query($getQuery);

        while($row = mysqli_fetch_assoc($data))
        {
            $opdNo[] = $row['OpdRegNo'];
        }
    }

    public function getNamesFromDb()
    {
        $getQuery = "SELECT * FROM patientregistration";

        $data  = $this->con->query($getQuery);

        while($row = mysqli_fetch_assoc($data))
        {
            $fullName[] = $row['FirstName']." ".$row['MiddleName']." ".$row['LastName'];
            $Opds[]     =   $row['OpdRegNo'];
        }

        $OpdWithNames = array_combine($Opds,$fullName);
        $getDoubleNames = array_count_values($OpdWithNames);
        
        foreach($getDoubleNames as $key=>$values)
        {
            if($values > 1)
            {
                
                foreach($OpdWithNames as $opdnumber => $name)
                {
                    if($name == $key)
                    {
                        $recordsName[]  =   $name;
                        $recordsOpd[]   =   $opdnumber;
                    }
                }
            }
        }

        $DuplicateRecods = array_combine($recordsOpd,$recordsName);
        echo "<pre>";
        print_r($DuplicateRecods);
        echo "</pre>";
    }

    public function getOpdFromDisk()
    {
        // $Source = "";

        // $foldersInSource = glob("$Source/*",GLOB_BRACE);
    }
}
$run = new getExceptions();
// $run->getOpdFromDb();
$run->getOpdFromDisk();
$run->getNamesFromDb();
?>